#include "heaps.h"

Heap *heapFromArray(string *input, int length) {
    //your code here
}

int numElements(Heap h) {
    //your code here
}

size_t lengthOfContent(Heap h) {
    //your code here
}


/* might want to do this for Q5
Heap **returnAllHeaps(Heap h) {
    //your code here
}*/

string *printLinear(Heap h) {
    //your code here
}


string printPretty(Heap h) {
    //your code here
}
