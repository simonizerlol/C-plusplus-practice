//QUESTION 1

#include "priorities.h"
#include <iostream>
#include <vector>
#include <map>
#include <sstream>


//QUESTION 1

Heap::Heap(const vector<string> & dataToAdd) {
    //TODO
}

Heap::Heap(const Heap& h) {
    //TODO
}


//Question 2

size_t Heap::lengthOfContent(unsigned long index) const {
    //TODO
}


ostream &operator<<(ostream & out, const Heap& h) {
    //TODO
}



//QUESTION 3

vector<string> Heap::printLinear() const{
    //TODO
}


//QUESTION 4

unsigned int Heap::operator[](string s) const{
    //TODO
}

//QUESTION 5

void Heap::heapifyUp(unsigned long index) {
    //TODO
}


void Heap::push(string data, unsigned int priority) {
    //TODO
}


Heap& Heap::operator+=(const Heap& h) {
    //TODO
}


// QUESTION 6

void Heap::heapifyDown(unsigned long index) {
    //TODO
}


string Heap::pop() {
    //TODO
}


// QUESTION 7

Heap::Heap(istream &in) {
    //TODO
}