#include "huffman.h"
#include <iostream>
#include <sstream>

//QUESTION 1 - 0 credit


HuffmanTree::HuffmanHeap::HuffmanHeap(istream &instr) {
    //TODO
}


void HuffmanTree::HuffmanHeap::pop() {
    //TODO
}



// QUESTION 2
void HuffmanTree::dfs(HuffmanCode& hc, TreeNode *tn, string &s) {
    //TODO
}

//QUESTION 3


HuffmanCode::HuffmanCode(istream &input) {
    //TODO
}



//QUESTION 4

HuffmanTree::HuffmanTree(const HuffmanCode &hc) {
    //TODO
}

// QUESTION 5

void HuffmanEncoder::encode(istream &fin, ostream &fout) const {
    //TODO
}


//QUESTION 5

void HuffmanDecoder::push(istream &f) {
    //TODO
}

